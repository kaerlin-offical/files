# Overview

NeonVault is a modern file management web application with a cyberpunk aesthetic featuring neon green highlights on a black background. The application provides public file downloads and an admin dashboard for file management. It's built as a full-stack application with React frontend and Express backend, featuring a clean separation between public and admin functionality.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React SPA**: Single-page application using Vite for development and build tooling
- **UI Framework**: shadcn/ui components with Radix UI primitives for consistent, accessible design
- **Styling**: Tailwind CSS with dark theme and neon green accent colors
- **State Management**: React Query (TanStack Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Visual Effects**: Custom Matrix-style animated canvas background for cyberpunk aesthetic

## Backend Architecture
- **Express Server**: RESTful API with middleware for logging, error handling, and session management
- **Storage Layer**: Abstracted storage interface with in-memory implementation (easily replaceable with database)
- **File Handling**: Multer for file upload processing with configurable size limits
- **Session Management**: Simple map-based session storage with expiration handling
- **Development Integration**: Vite middleware integration for seamless full-stack development

## Authentication & Authorization
- **Admin Authentication**: Single admin code verification system
- **Session-based**: Server-side session management with 24-hour expiration
- **Public Access**: Downloads and browsing available without authentication
- **Secure Design**: Admin code never exposed to frontend, server-side validation only

## Data Models
- **Categories**: Hierarchical organization with icons and metadata
- **Files**: Metadata tracking with download counts and category relationships
- **Download Logs**: Audit trail for download activity and statistics
- **Users**: Admin user management (extensible for future multi-user support)

## File Management
- **Upload System**: Drag-and-drop interface with 100MB file size limit
- **Categorization**: Flexible category system with icon support
- **Download Tracking**: Real-time download statistics and logging
- **File Organization**: Server-side file storage with unique identifiers

## UI/UX Design Patterns
- **Responsive Design**: Mobile-first approach with collapsible navigation
- **Dark Theme**: Consistent cyberpunk aesthetic with neon green accents
- **Interactive Elements**: Hover effects, animations, and visual feedback
- **Accessibility**: ARIA-compliant components via Radix UI
- **Progressive Enhancement**: Graceful degradation for various device capabilities

# External Dependencies

## Core Framework Dependencies
- **@neondatabase/serverless**: PostgreSQL database client (configured but using in-memory storage)
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect configuration
- **express**: Web application framework for REST API
- **react**: Frontend UI library with hooks and modern patterns
- **@tanstack/react-query**: Server state synchronization and caching

## UI Component Libraries
- **@radix-ui/***: Comprehensive suite of accessible, unstyled UI primitives
- **tailwindcss**: Utility-first CSS framework for rapid styling
- **framer-motion**: Animation library for smooth UI transitions
- **lucide-react**: Icon library for consistent visual elements

## Development & Build Tools
- **vite**: Frontend build tool and development server
- **typescript**: Type safety across the entire application
- **tsx**: TypeScript execution for Node.js development
- **esbuild**: Fast JavaScript bundler for production builds

## File Processing & Utilities
- **multer**: Multipart form data handling for file uploads
- **date-fns**: Date manipulation and formatting utilities
- **clsx**: Conditional className utility for dynamic styling
- **class-variance-authority**: Type-safe component variant system

## Development Quality Tools
- **drizzle-kit**: Database schema management and migrations
- **@replit/***: Replit-specific development enhancements
- **connect-pg-simple**: PostgreSQL session store (configured for future use)