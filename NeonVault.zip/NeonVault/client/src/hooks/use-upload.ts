import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';

export interface UploadProgress {
  fileId: string;
  fileName: string;
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
}

export function useUpload() {
  const [uploads, setUploads] = useState<Map<string, UploadProgress>>(new Map());
  const { toast } = useToast();

  const uploadFiles = useCallback(async (files: FileList, categoryId?: string) => {
    const fileArray = Array.from(files);
    const formData = new FormData();
    
    // Initialize progress tracking
    const newUploads = new Map<string, UploadProgress>();
    fileArray.forEach((file, index) => {
      const fileId = `${Date.now()}-${index}`;
      newUploads.set(fileId, {
        fileId,
        fileName: file.name,
        progress: 0,
        status: 'pending',
      });
      formData.append('files', file);
    });

    if (categoryId) {
      formData.append('categoryId', categoryId);
    }

    setUploads(prev => {
      const updated = new Map(prev);
      newUploads.forEach((value, key) => updated.set(key, value));
      return updated;
    });

    try {
      // Create XMLHttpRequest for progress tracking
      const xhr = new XMLHttpRequest();
      
      return new Promise<any>((resolve, reject) => {
        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            const progress = Math.round((event.loaded * 100) / event.total);
            
            // Update progress for all files in this upload
            setUploads(prev => {
              const updated = new Map(prev);
              newUploads.forEach((_, fileId) => {
                const current = updated.get(fileId);
                if (current) {
                  updated.set(fileId, {
                    ...current,
                    progress,
                    status: progress === 100 ? 'completed' : 'uploading',
                  });
                }
              });
              return updated;
            });
          }
        };

        xhr.onload = () => {
          if (xhr.status === 201) {
            const result = JSON.parse(xhr.responseText);
            
            // Mark all files as completed
            setUploads(prev => {
              const updated = new Map(prev);
              newUploads.forEach((_, fileId) => {
                updated.set(fileId, {
                  ...updated.get(fileId)!,
                  progress: 100,
                  status: 'completed',
                });
              });
              return updated;
            });

            toast({
              title: 'Upload successful',
              description: `${result.length} file(s) uploaded successfully.`,
            });

            resolve(result);
          } else {
            throw new Error(`Upload failed with status ${xhr.status}`);
          }
        };

        xhr.onerror = () => {
          // Mark all files as error
          setUploads(prev => {
            const updated = new Map(prev);
            newUploads.forEach((_, fileId) => {
              updated.set(fileId, {
                ...updated.get(fileId)!,
                status: 'error',
                error: 'Upload failed',
              });
            });
            return updated;
          });

          toast({
            variant: 'destructive',
            title: 'Upload failed',
            description: 'Failed to upload files. Please try again.',
          });

          reject(new Error('Upload failed'));
        };

        const sessionId = localStorage.getItem('adminSessionId');
        xhr.open('POST', '/api/files/upload');
        if (sessionId) {
          xhr.setRequestHeader('Authorization', `Bearer ${sessionId}`);
        }
        xhr.send(formData);
      });
    } catch (error) {
      console.error('Upload error:', error);
      
      // Mark all files as error
      setUploads(prev => {
        const updated = new Map(prev);
        newUploads.forEach((_, fileId) => {
          updated.set(fileId, {
            ...updated.get(fileId)!,
            status: 'error',
            error: error instanceof Error ? error.message : 'Unknown error',
          });
        });
        return updated;
      });

      throw error;
    }
  }, [toast]);

  const clearUpload = useCallback((fileId: string) => {
    setUploads(prev => {
      const updated = new Map(prev);
      updated.delete(fileId);
      return updated;
    });
  }, []);

  const clearAllUploads = useCallback(() => {
    setUploads(new Map());
  }, []);

  return {
    uploads: Array.from(uploads.values()),
    uploadFiles,
    clearUpload,
    clearAllUploads,
  };
}