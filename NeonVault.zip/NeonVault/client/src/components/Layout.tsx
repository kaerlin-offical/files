import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import MatrixBackground from "./MatrixBackground";
import { Menu, Shield, Home, Book, HelpCircle, Download } from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/docs", label: "Docs", icon: Book },
    { href: "/faq", label: "FAQ", icon: HelpCircle },
    { href: "/downloads", label: "Downloads", icon: Download },
    { href: "/admin", label: "Admin", icon: Shield },
  ];

  const isActive = (href: string) => {
    if (href === "/") return location === "/";
    return location.startsWith(href);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <MatrixBackground />
      
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 glass-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" data-testid="link-home">
              <motion.div 
                className="flex items-center space-x-2 cursor-pointer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <div className="text-primary text-xl">
                  <i className="fas fa-vault"></i>
                </div>
                <span className="font-mono font-bold text-xl text-primary">
                  NeonVault
                </span>
              </motion.div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="flex items-center space-x-8">
                {navItems.map(({ href, label, icon: Icon }) => (
                  <Link key={href} href={href} data-testid={`link-${label.toLowerCase()}`}>
                    <motion.div
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors duration-200 cursor-pointer ${
                        isActive(href)
                          ? "text-primary bg-primary/10"
                          : "text-foreground hover:text-primary hover:bg-primary/5"
                      }`}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Icon size={16} />
                      <span>{label}</span>
                    </motion.div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-foreground hover:text-primary"
                    data-testid="button-mobile-menu"
                  >
                    <Menu size={24} />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="glass-card border-l border-border">
                  <div className="flex flex-col space-y-4 mt-8">
                    {navItems.map(({ href, label, icon: Icon }) => (
                      <Link key={href} href={href} data-testid={`link-mobile-${label.toLowerCase()}`}>
                        <motion.div
                          className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors duration-200 cursor-pointer ${
                            isActive(href)
                              ? "text-primary bg-primary/10"
                              : "text-foreground hover:text-primary hover:bg-primary/5"
                          }`}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <Icon size={20} />
                          <span className="text-lg">{label}</span>
                        </motion.div>
                      </Link>
                    ))}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-16 min-h-screen">
        {children}
      </main>
    </div>
  );
}
