import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { useUpload } from "@/hooks/use-upload";
import { apiRequest } from "@/lib/queryClient";
import {
  LogOut,
  Upload,
  File,
  Download,
  Folder,
  HardDrive,
  Plus,
  Trash2,
  Edit,
  CloudUpload,
  FolderOpen,
} from "lucide-react";
import type { FileWithCategory, Category } from "@shared/schema";

interface AdminStats {
  totalFiles: number;
  totalCategories: number;
  totalDownloads: number;
  downloadsToday: number;
  filesAddedToday: number;
}

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const [newCategoryName, setNewCategoryName] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [dragOver, setDragOver] = useState(false);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isConnected, onMessage, offMessage } = useWebSocket();
  const { uploads, uploadFiles, clearAllUploads } = useUpload();

  // Check admin authentication
  useEffect(() => {
    const sessionId = localStorage.getItem("adminSessionId");
    if (!sessionId) {
      setLocation("/admin");
    }
  }, [setLocation]);

  // Set up WebSocket handlers for real-time updates
  useEffect(() => {
    onMessage('file_downloaded', (data) => {
      setRecentActivity(prev => [{
        id: Date.now(),
        type: 'download',
        message: `File downloaded: ${data.fileName}`,
        timestamp: data.timestamp,
      }, ...prev.slice(0, 9)]);
      
      // Refresh stats and files
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
    });
    
    onMessage('file_uploaded', (data) => {
      setRecentActivity(prev => [{
        id: Date.now(),
        type: 'upload', 
        message: `New file uploaded: ${data.file.originalName}`,
        timestamp: data.timestamp,
      }, ...prev.slice(0, 9)]);
      
      // Refresh stats and files
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
    });
    
    onMessage('category_created', (data) => {
      setRecentActivity(prev => [{
        id: Date.now(),
        type: 'category',
        message: `Category '${data.category.name}' created`,
        timestamp: data.timestamp,
      }, ...prev.slice(0, 9)]);
      
      // Refresh categories
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
    });
    
    return () => {
      offMessage('file_downloaded');
      offMessage('file_uploaded');
      offMessage('category_created');
    };
  }, [onMessage, offMessage, queryClient]);

  const getAuthHeaders = (): Record<string, string> => {
    const sessionId = localStorage.getItem("adminSessionId");
    return sessionId ? { Authorization: `Bearer ${sessionId}` } : {};
  };

  const { data: stats, isLoading: statsLoading } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
    queryFn: async () => {
      const authHeaders = getAuthHeaders();
      const response = await fetch("/api/admin/stats", {
        headers: authHeaders,
      });
      if (!response.ok) throw new Error("Failed to fetch stats");
      return response.json();
    },
  });

  const { data: files = [] } = useQuery<FileWithCategory[]>({
    queryKey: ["/api/files"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const authHeaders = getAuthHeaders();
      await fetch("/api/admin/logout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...authHeaders,
        },
        body: JSON.stringify({}),
      });
    },
    onSettled: () => {
      localStorage.removeItem("adminSessionId");
      setLocation("/");
    },
  });

  const createCategoryMutation = useMutation({
    mutationFn: async (name: string) => {
      const authHeaders = getAuthHeaders();
      const response = await fetch("/api/categories", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...authHeaders,
        },
        body: JSON.stringify({ name, icon: "fas fa-folder" }),
      });
      if (!response.ok) throw new Error("Failed to create category");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Category created",
        description: "New category has been added successfully.",
      });
      setNewCategoryName("");
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to create category",
        description: error.message,
      });
    },
  });

  const deleteCategoryMutation = useMutation({
    mutationFn: async (categoryId: string) => {
      const authHeaders = getAuthHeaders();
      const response = await fetch(`/api/categories/${categoryId}`, {
        method: "DELETE",
        headers: authHeaders,
      });
      if (!response.ok) throw new Error("Failed to delete category");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Category deleted",
        description: "Category has been removed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to delete category",
        description: error.message,
      });
    },
  });

  const deleteFileMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const authHeaders = getAuthHeaders();
      const response = await fetch(`/api/files/${fileId}`, {
        method: "DELETE",
        headers: authHeaders,
      });
      if (!response.ok) throw new Error("Failed to delete file");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "File deleted",
        description: "File has been removed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to delete file",
        description: error.message,
      });
    },
  });

  const handleUpload = async () => {
    if (selectedFiles) {
      try {
        await uploadFiles(selectedFiles, selectedCategory);
        setSelectedFiles(null);
        queryClient.invalidateQueries({ queryKey: ["/api/files"] });
        queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      } catch (error) {
        console.error('Upload failed:', error);
      }
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCategoryName.trim()) {
      createCategoryMutation.mutate(newCategoryName.trim());
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(e.target.files);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files) {
      setSelectedFiles(e.dataTransfer.files);
    }
  };


  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <motion.div
        className="flex items-center justify-between mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center space-x-4">
          <h1 className="text-4xl font-bold font-mono text-primary">Admin Dashboard</h1>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${
              isConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'
            }`}></div>
            <span className="text-sm text-muted-foreground">
              {isConnected ? 'Real-time Connected' : 'Disconnected'}
            </span>
          </div>
        </div>
        <Button
          variant="outline"
          onClick={handleLogout}
          className="border-border hover:border-primary"
          disabled={logoutMutation.isPending}
          data-testid="button-logout"
        >
          <LogOut className="mr-2" size={16} />
          Logout
        </Button>
      </motion.div>

      {/* Real-time Stats */}
      <motion.div
        className="grid md:grid-cols-4 gap-6 mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        {statsLoading ? (
          [...Array(4)].map((_, i) => (
            <div key={i} className="glass-card p-6 rounded-lg animate-pulse">
              <div className="h-16 bg-secondary rounded"></div>
            </div>
          ))
        ) : (
          [
            { icon: File, label: "Total Files", value: stats?.totalFiles || 0, change: `+${stats?.filesAddedToday || 0} today` },
            { icon: Download, label: "Total Downloads", value: stats?.totalDownloads || 0, change: `+${stats?.downloadsToday || 0} today` },
            { icon: Folder, label: "Categories", value: stats?.totalCategories || 0, change: "+2 this week" },
            { icon: HardDrive, label: "Storage Used", value: "12.4GB", change: "68% of limit" },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.2 + index * 0.1 }}
            >
              <Card className="glass-card neon-glow" data-testid={`card-stat-${index}`}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-muted-foreground">{stat.label}</p>
                      <p className="text-3xl font-bold text-primary">{stat.value}</p>
                    </div>
                    <stat.icon className="text-primary" size={24} />
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    <span className="text-green-400">{stat.change}</span>
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))
        )}
      </motion.div>

      {/* File Upload Area */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <Card className="glass-card mb-8" data-testid="card-upload">
          <CardHeader>
            <CardTitle className="text-2xl text-accent">Upload Files</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div
              className={`drag-area border-2 border-dashed rounded-lg p-8 text-center transition-all duration-300 ${
                dragOver ? "border-primary bg-primary/10" : "border-border"
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              data-testid="area-file-drop"
            >
              <CloudUpload className="mx-auto text-6xl text-muted-foreground mb-4" />
              <p className="text-xl font-semibold mb-2">Drag & Drop Files Here</p>
              <p className="text-muted-foreground mb-4">or click to browse</p>
              <input
                type="file"
                id="file-upload"
                multiple
                className="hidden"
                onChange={handleFileSelect}
                data-testid="input-file-upload"
              />
              <Button
                onClick={() => document.getElementById("file-upload")?.click()}
                className="neon-border bg-primary/10 hover:bg-primary/20 text-primary"
                data-testid="button-browse-files"
              >
                <FolderOpen className="mr-2" size={16} />
                Browse Files
              </Button>
            </div>

            {selectedFiles && selectedFiles.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <Select value={selectedCategory} onValueChange={setSelectedCategory} data-testid="select-upload-category">
                    <SelectTrigger className="bg-input border-border focus:border-primary">
                      <SelectValue placeholder="Select category (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button
                    onClick={handleUpload}
                    className="neon-border bg-primary/10 hover:bg-primary/20 text-primary"
                    disabled={uploads.some(u => u.status === 'uploading')}
                    data-testid="button-upload"
                  >
                    {uploads.some(u => u.status === 'uploading') ? (
                      <div className="flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
                        Uploading...
                      </div>
                    ) : (
                      <>
                        <Upload className="mr-2" size={16} />
                        Upload {selectedFiles.length} file(s)
                      </>
                    )}
                  </Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  Selected: {Array.from(selectedFiles).map(f => f.name).join(", ")}
                </div>
              </div>
            )}
            
            {/* Upload Progress Display */}
            {uploads.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Upload Progress</h4>
                {uploads.map((upload) => (
                  <div key={upload.fileId} className="bg-secondary/50 p-3 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">{upload.fileName}</span>
                      <span className="text-xs text-muted-foreground">
                        {upload.status === 'completed' ? 'Completed' : 
                         upload.status === 'error' ? 'Error' : 
                         upload.status === 'uploading' ? `${upload.progress}%` : 'Pending'}
                      </span>
                    </div>
                    <div className="w-full bg-border rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full transition-all duration-300 ${
                          upload.status === 'error' ? 'bg-red-400' : 
                          upload.status === 'completed' ? 'bg-green-400' : 'bg-primary'
                        }`}
                        style={{ width: `${upload.progress}%` }}
                      ></div>
                    </div>
                    {upload.error && (
                      <p className="text-xs text-red-400 mt-1">{upload.error}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Category Management and Recent Activity */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <Card className="glass-card" data-testid="card-categories">
            <CardHeader>
              <CardTitle className="text-2xl text-accent">Categories</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                {categories.map(category => (
                  <div
                    key={category.id}
                    className="flex items-center justify-between p-3 border border-border rounded-lg"
                    data-testid={`category-item-${category.id}`}
                  >
                    <div className="flex items-center space-x-3">
                      <i className={`${category.icon} text-primary`}></i>
                      <span>{category.name}</span>
                      <Badge variant="secondary">
                        ({files.filter(f => f.categoryId === category.id).length} files)
                      </Badge>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteCategoryMutation.mutate(category.id)}
                      className="text-red-400 hover:text-red-300"
                      disabled={deleteCategoryMutation.isPending}
                      data-testid={`button-delete-category-${category.id}`}
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                ))}
              </div>

              <form onSubmit={handleCreateCategory} className="flex space-x-2">
                <Input
                  type="text"
                  placeholder="New category name..."
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  className="flex-1 bg-input border-border focus:border-primary focus:ring-primary/20"
                  data-testid="input-new-category"
                />
                <Button
                  type="submit"
                  size="sm"
                  className="neon-border bg-primary/10 hover:bg-primary/20 text-primary"
                  disabled={createCategoryMutation.isPending || !newCategoryName.trim()}
                  data-testid="button-add-category"
                >
                  <Plus size={16} />
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
        >
          <Card className="glass-card" data-testid="card-recent-activity">
            <CardHeader>
              <CardTitle className="text-2xl text-accent">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentActivity.length > 0 ? (
                  recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-center space-x-3 p-3 bg-secondary/50 rounded-lg">
                      <div className={`w-2 h-2 rounded-full ${
                        activity.type === 'download' ? 'bg-green-400 animate-pulse' : 
                        activity.type === 'upload' ? 'bg-blue-400' : 
                        'bg-yellow-400'
                      }`}></div>
                      <div className="flex-1">
                        <p className="text-sm">{activity.message}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(activity.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-muted-foreground">
                    <p className="text-sm">No recent activity</p>
                    <p className="text-xs">Real-time updates will appear here</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* File Management */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
      >
        <Card className="glass-card" data-testid="card-file-management">
          <CardHeader>
            <CardTitle className="text-2xl text-accent">File Management</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4">File Name</th>
                    <th className="text-left py-3 px-4">Category</th>
                    <th className="text-left py-3 px-4">Size</th>
                    <th className="text-left py-3 px-4">Downloads</th>
                    <th className="text-left py-3 px-4">Upload Date</th>
                    <th className="text-left py-3 px-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {files.map((file) => (
                    <tr key={file.id} className="hover:bg-secondary/20" data-testid={`row-file-${file.id}`}>
                      <td className="py-3 px-4">
                        <div className="flex items-center space-x-2">
                          <File className="text-primary" size={16} />
                          <span className="truncate max-w-xs">{file.originalName}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {file.category?.name || "Uncategorized"}
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {formatFileSize(file.size)}
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-primary font-semibold">
                          {file.downloadCount.toLocaleString()}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {new Date(file.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-primary hover:text-accent"
                            data-testid={`button-edit-${file.id}`}
                          >
                            <Edit size={16} />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => deleteFileMutation.mutate(file.id)}
                            className="text-red-400 hover:text-red-300"
                            disabled={deleteFileMutation.isPending}
                            data-testid={`button-delete-${file.id}`}
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
