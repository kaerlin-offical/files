import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Download, Book, Shield, Zap, Settings } from "lucide-react";

export default function Home() {
  const features = [
    {
      icon: Shield,
      title: "Secure Storage",
      description: "Advanced encryption and access control systems protect your files.",
    },
    {
      icon: Zap,
      title: "Real-time Updates",
      description: "Live monitoring of downloads, uploads, and system activity.",
    },
    {
      icon: Settings,
      title: "Admin Control",
      description: "Comprehensive dashboard for file and category management.",
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-16">
      {/* Hero Section */}
      <motion.div
        className="text-center mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <motion.h1 
          className="text-5xl md:text-7xl font-bold mb-6 font-mono"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <span className="text-primary animate-pulse-neon">NEON</span>
          <span className="text-foreground">VAULT</span>
        </motion.h1>
        
        <motion.p 
          className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          Secure file management system with real-time monitoring and advanced admin controls.
          Built for the digital age with cyberpunk aesthetics.
        </motion.p>
        
        <motion.div 
          className="flex flex-wrap gap-4 justify-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <Link href="/downloads">
            <Button 
              className="neon-border neon-glow bg-primary/10 hover:bg-primary/20 text-primary border-primary px-6 py-3"
              data-testid="button-browse-files"
            >
              <Download className="mr-2" size={16} />
              Browse Files
            </Button>
          </Link>
          <Link href="/docs">
            <Button 
              variant="outline" 
              className="border-border hover:border-primary px-6 py-3"
              data-testid="button-documentation"
            >
              <Book className="mr-2" size={16} />
              Documentation
            </Button>
          </Link>
        </motion.div>
      </motion.div>

      {/* Feature Grid */}
      <motion.div 
        className="grid md:grid-cols-3 gap-6 mb-16"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.8 }}
      >
        {features.map((feature, index) => (
          <motion.div
            key={feature.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 + index * 0.1 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Card className="glass-card neon-glow h-full cursor-pointer" data-testid={`card-feature-${index}`}>
              <CardContent className="p-6">
                <div className="text-primary text-3xl mb-4">
                  <feature.icon size={32} />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Quick Stats */}
      <motion.div 
        className="glass-card p-8 rounded-lg text-center"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 1.2 }}
      >
        <h2 className="text-2xl font-bold mb-6 text-accent">System Status</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div data-testid="stat-files">
            <div className="text-3xl font-bold text-primary mb-2">247</div>
            <div className="text-sm text-muted-foreground">Files Available</div>
          </div>
          <div data-testid="stat-downloads">
            <div className="text-3xl font-bold text-primary mb-2">15.4K</div>
            <div className="text-sm text-muted-foreground">Total Downloads</div>
          </div>
          <div data-testid="stat-categories">
            <div className="text-3xl font-bold text-primary mb-2">8</div>
            <div className="text-sm text-muted-foreground">Categories</div>
          </div>
          <div data-testid="stat-uptime">
            <div className="text-3xl font-bold text-primary mb-2">99.9%</div>
            <div className="text-sm text-muted-foreground">Uptime</div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
