import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, Download, Eye, Flame, FileText, Settings, Image, PlayCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/use-websocket";
import { apiRequest } from "@/lib/queryClient";
import type { FileWithCategory, Category } from "@shared/schema";

export default function Downloads() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { onMessage, offMessage } = useWebSocket();

  // Set up real-time download counter updates
  useEffect(() => {
    onMessage('file_downloaded', (data) => {
      // Show real-time toast notification
      toast({
        title: "File Downloaded",
        description: `${data.fileName} was just downloaded!`,
        duration: 3000,
      });
      
      // Update file list with new download counts
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
    });
    
    onMessage('file_uploaded', (data) => {
      toast({
        title: "New File Available",
        description: `${data.file.originalName} is now available for download!`,
        duration: 4000,
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
    });
    
    return () => {
      offMessage('file_downloaded');
      offMessage('file_uploaded');
    };
  }, [onMessage, offMessage, toast, queryClient]);

  const { data: files = [], isLoading: filesLoading } = useQuery<FileWithCategory[]>({
    queryKey: ["/api/files"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const downloadMutation = useMutation({
    mutationFn: async (fileId: string) => {
      const response = await apiRequest("POST", `/api/files/${fileId}/download`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Download started",
        description: "Your file download has been initiated.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Download failed",
        description: error.message,
      });
    },
  });

  const filteredFiles = files
    .filter(file => {
      const matchesSearch = file.originalName.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === "all" || file.categoryId === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "name":
          return a.originalName.localeCompare(b.originalName);
        case "date":
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case "downloads":
          return b.downloadCount - a.downloadCount;
        case "size":
          return b.size - a.size;
        default:
          return 0;
      }
    });

  const mostDownloadedFiles = files
    .sort((a, b) => b.downloadCount - a.downloadCount)
    .slice(0, 3);

  const filesByCategory = categories.map(category => ({
    category,
    files: files.filter(file => file.categoryId === category.id),
  })).filter(group => group.files.length > 0);

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith("image/")) return <Image className="text-blue-500" size={20} />;
    if (mimeType.includes("pdf")) return <FileText className="text-red-500" size={20} />;
    if (mimeType.includes("video/") || mimeType.includes("audio/")) return <PlayCircle className="text-purple-500" size={20} />;
    if (mimeType.includes("zip") || mimeType.includes("archive")) return <Settings className="text-yellow-500" size={20} />;
    return <FileText className="text-gray-500" size={20} />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const canPreview = (mimeType: string) => {
    return mimeType.startsWith("image/") || mimeType.includes("pdf");
  };

  const handleDownload = (fileId: string) => {
    downloadMutation.mutate(fileId);
  };

  if (filesLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-secondary rounded w-1/4"></div>
          <div className="h-12 bg-secondary rounded"></div>
          <div className="grid md:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-32 bg-secondary rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <motion.h1
        className="text-4xl font-bold mb-8 font-mono text-primary"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        Public Downloads
      </motion.h1>

      {/* Search and Filter Controls */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <Card className="glass-card p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Input
                type="text"
                placeholder="Search files..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-input border-border pl-10 focus:border-primary focus:ring-primary/20"
                data-testid="input-search-files"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory} data-testid="select-category">
              <SelectTrigger className="bg-input border-border focus:border-primary">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy} data-testid="select-sort">
              <SelectTrigger className="bg-input border-border focus:border-primary">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Sort by Name</SelectItem>
                <SelectItem value="date">Sort by Date</SelectItem>
                <SelectItem value="downloads">Sort by Downloads</SelectItem>
                <SelectItem value="size">Sort by Size</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>
      </motion.div>

      {/* Most Downloaded Section */}
      {mostDownloadedFiles.length > 0 && (
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <h2 className="text-2xl font-semibold mb-4 text-accent flex items-center">
            <Flame className="mr-2 text-primary" />
            Most Downloaded
          </h2>
          <div className="grid md:grid-cols-3 gap-4">
            {mostDownloadedFiles.map((file, index) => (
              <motion.div
                key={file.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                data-testid={`card-popular-${index}`}
              >
                <Card className="glass-card neon-glow h-full">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold truncate">{file.originalName}</span>
                      <span className="text-sm text-primary">{formatFileSize(file.size)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">
                        {file.downloadCount.toLocaleString()} downloads
                      </span>
                      <div className="flex space-x-2">
                        {canPreview(file.mimeType) && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-primary hover:text-accent"
                            data-testid={`button-preview-${file.id}`}
                          >
                            <Eye size={16} />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          className="neon-border bg-primary/10 hover:bg-primary/20 text-primary"
                          onClick={() => handleDownload(file.id)}
                          disabled={downloadMutation.isPending}
                          data-testid={`button-download-${file.id}`}
                        >
                          <Download size={16} className="mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* File Categories */}
      <motion.div
        className="space-y-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
      >
        {selectedCategory === "all" ? (
          filesByCategory.map((group, groupIndex) => (
            <motion.div
              key={group.category.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.5 + groupIndex * 0.1 }}
            >
              <Card className="glass-card overflow-hidden" data-testid={`card-category-${group.category.name.toLowerCase()}`}>
                <CardHeader className="bg-accent/20 border-b border-border">
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className={`${group.category.icon} mr-2 text-primary`}></i>
                      {group.category.name}
                    </div>
                    <Badge variant="secondary">
                      {group.files.length} files
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid gap-4">
                    {group.files.slice(0, 5).map((file) => (
                      <div
                        key={file.id}
                        className="flex items-center justify-between p-4 border border-border rounded-lg hover:border-primary transition-colors"
                        data-testid={`file-item-${file.id}`}
                      >
                        <div className="flex items-center space-x-4">
                          {getFileIcon(file.mimeType)}
                          <div>
                            <h4 className="font-medium">{file.originalName}</h4>
                            <p className="text-sm text-muted-foreground">
                              {formatFileSize(file.size)}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <span className="text-sm text-muted-foreground">
                            {file.downloadCount} downloads
                          </span>
                          {canPreview(file.mimeType) && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-primary hover:text-accent"
                              data-testid={`button-preview-${file.id}`}
                            >
                              <Eye size={16} />
                            </Button>
                          )}
                          <Button
                            size="sm"
                            className="neon-border bg-primary/10 hover:bg-primary/20 text-primary"
                            onClick={() => handleDownload(file.id)}
                            disabled={downloadMutation.isPending}
                            data-testid={`button-download-${file.id}`}
                          >
                            <Download size={16} className="mr-1" />
                            Download
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))
        ) : (
          <Card className="glass-card overflow-hidden">
            <CardContent className="p-6">
              <div className="grid gap-4">
                {filteredFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg hover:border-primary transition-colors"
                    data-testid={`file-item-${file.id}`}
                  >
                    <div className="flex items-center space-x-4">
                      {getFileIcon(file.mimeType)}
                      <div>
                        <h4 className="font-medium">{file.originalName}</h4>
                        <p className="text-sm text-muted-foreground">
                          {file.category?.name} • {formatFileSize(file.size)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <span className="text-sm text-muted-foreground">
                        {file.downloadCount} downloads
                      </span>
                      {canPreview(file.mimeType) && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-primary hover:text-accent"
                          data-testid={`button-preview-${file.id}`}
                        >
                          <Eye size={16} />
                        </Button>
                      )}
                      <Button
                        size="sm"
                        className="neon-border bg-primary/10 hover:bg-primary/20 text-primary"
                        onClick={() => handleDownload(file.id)}
                        disabled={downloadMutation.isPending}
                        data-testid={`button-download-${file.id}`}
                      >
                        <Download size={16} className="mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </motion.div>

      {filteredFiles.length === 0 && searchTerm && (
        <motion.div
          className="text-center py-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4 }}
        >
          <p className="text-muted-foreground" data-testid="text-no-files">
            No files found matching "{searchTerm}"
          </p>
        </motion.div>
      )}
    </div>
  );
}
