import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertCategorySchema, insertFileSchema, insertDownloadLogSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit
  },
});

const ADMIN_CODE = "b1c0f3a1e7d8c9f4a6b2d1e3f7c8a9d5e0f1b3c4d7a8e9f6c2b5d4f3a1e7c0b8";

// Session management
const sessions = new Map<string, { isAdmin: boolean; createdAt: Date }>();

// WebSocket connections
const wsConnections = new Set<WebSocket>();

// Broadcast to all connected clients
function broadcast(data: any) {
  const message = JSON.stringify(data);
  wsConnections.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(message);
    }
  });
}

function generateSessionId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

function isValidSession(sessionId: string): boolean {
  const session = sessions.get(sessionId);
  if (!session) return false;
  
  // Sessions expire after 24 hours
  const expirationTime = 24 * 60 * 60 * 1000;
  if (Date.now() - session.createdAt.getTime() > expirationTime) {
    sessions.delete(sessionId);
    return false;
  }
  
  return session.isAdmin;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Categories endpoints
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", async (req, res) => {
    const sessionId = req.headers.authorization?.replace("Bearer ", "");
    if (!sessionId || !isValidSession(sessionId)) {
      return res.status(401).json({ error: "Admin authentication required" });
    }

    try {
      const result = insertCategorySchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: "Invalid category data", details: result.error.errors });
      }

      const category = await storage.createCategory(result.data);
      
      // Broadcast real-time update
      broadcast({
        type: 'category_created',
        data: {
          category,
          timestamp: new Date().toISOString(),
        },
      });
      
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ error: "Failed to create category" });
    }
  });

  app.delete("/api/categories/:id", async (req, res) => {
    const sessionId = req.headers.authorization?.replace("Bearer ", "");
    if (!sessionId || !isValidSession(sessionId)) {
      return res.status(401).json({ error: "Admin authentication required" });
    }

    try {
      const success = await storage.deleteCategory(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete category" });
    }
  });

  // Files endpoints
  app.get("/api/files", async (req, res) => {
    try {
      const files = await storage.getFiles();
      res.json(files);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch files" });
    }
  });

  app.get("/api/files/:id", async (req, res) => {
    try {
      const file = await storage.getFile(req.params.id);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      res.json(file);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch file" });
    }
  });

  app.post("/api/files/upload", upload.array("files"), async (req, res) => {
    const sessionId = req.headers.authorization?.replace("Bearer ", "");
    if (!sessionId || !isValidSession(sessionId)) {
      return res.status(401).json({ error: "Admin authentication required" });
    }

    try {
      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "No files uploaded" });
      }

      const uploadedFiles = [];
      
      for (const file of files) {
        const fileData = {
          name: file.filename,
          originalName: file.originalname,
          size: file.size,
          mimeType: file.mimetype,
          categoryId: req.body.categoryId || null,
        };

        const result = insertFileSchema.safeParse(fileData);
        if (!result.success) {
          continue; // Skip invalid files
        }

        const savedFile = await storage.createFile(result.data);
        uploadedFiles.push(savedFile);
        
        // Broadcast real-time update for each uploaded file
        broadcast({
          type: 'file_uploaded',
          data: {
            file: savedFile,
            timestamp: new Date().toISOString(),
          },
        });
      }

      res.status(201).json(uploadedFiles);
    } catch (error) {
      res.status(500).json({ error: "Failed to upload files" });
    }
  });

  app.delete("/api/files/:id", async (req, res) => {
    const sessionId = req.headers.authorization?.replace("Bearer ", "");
    if (!sessionId || !isValidSession(sessionId)) {
      return res.status(401).json({ error: "Admin authentication required" });
    }

    try {
      const file = await storage.getFile(req.params.id);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      // Delete physical file
      const filePath = path.join(uploadDir, file.name);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

      const success = await storage.deleteFile(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "File not found" });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete file" });
    }
  });

  app.post("/api/files/:id/download", async (req, res) => {
    try {
      const file = await storage.getFile(req.params.id);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }

      // Update download count
      await storage.updateFileDownloadCount(req.params.id);
      
      // Log download
      await storage.createDownloadLog({ fileId: req.params.id });

      // Broadcast real-time update
      broadcast({
        type: 'file_downloaded',
        data: {
          fileId: req.params.id,
          fileName: file.originalName,
          downloadCount: file.downloadCount + 1,
          timestamp: new Date().toISOString(),
        },
      });

      // In a real implementation, you would serve the actual file here
      // For now, we'll just return success
      res.json({ success: true, message: "Download initiated" });
    } catch (error) {
      res.status(500).json({ error: "Failed to initiate download" });
    }
  });

  // Admin authentication
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { code } = req.body;
      
      if (code !== ADMIN_CODE) {
        return res.status(401).json({ error: "Invalid authentication code" });
      }

      const sessionId = generateSessionId();
      sessions.set(sessionId, {
        isAdmin: true,
        createdAt: new Date(),
      });

      res.json({ sessionId, success: true });
    } catch (error) {
      res.status(500).json({ error: "Authentication failed" });
    }
  });

  app.post("/api/admin/logout", async (req, res) => {
    const sessionId = req.headers.authorization?.replace("Bearer ", "");
    if (sessionId) {
      sessions.delete(sessionId);
    }
    res.json({ success: true });
  });

  // Admin stats
  app.get("/api/admin/stats", async (req, res) => {
    const sessionId = req.headers.authorization?.replace("Bearer ", "");
    if (!sessionId || !isValidSession(sessionId)) {
      return res.status(401).json({ error: "Admin authentication required" });
    }

    try {
      const files = await storage.getFiles();
      const categories = await storage.getCategories();
      const downloadStats = await storage.getDownloadStats();

      const stats = {
        totalFiles: files.length,
        totalCategories: categories.length,
        totalDownloads: downloadStats.totalDownloads,
        downloadsToday: downloadStats.downloadsToday,
        filesAddedToday: files.filter(f => {
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          return f.createdAt >= today;
        }).length,
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  
  // Set up WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('New WebSocket connection');
    wsConnections.add(ws);
    
    // Send initial connection confirmation
    ws.send(JSON.stringify({ type: 'connected', message: 'Real-time connection established' }));
    
    ws.on('close', () => {
      console.log('WebSocket connection closed');
      wsConnections.delete(ws);
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      wsConnections.delete(ws);
    });
  });
  
  return httpServer;
}
